The EZ Learning Institute is an online-based educational website that serves as a platform for an educational institution to conduct online academic activities such as academic registration, access to study materials, student performance and progress management etc. with precision. Currently, it consists of four independent users including admin, teacher. 

There are 2-types of Users here. They are:

•Admin
•Teacher

--> Feature List:

In this project the User Type “Admin” has the following features:

•	Registration
•	Login
•	View and Update Profile
•	Change Password
•	View + Add teacher and Delete
•	View + Add Student and Delete
•	Query Session
•	Upload news and events
•	Registration Approval
•	Student's Fee
•	Teacher's salary report
•	Update Terms & Conditions

In this project the User Type “Teacher” has the following features:

•	Registration
•	Login
•	View and Update Profile
•	Change password
•	Add Student and Delete
•	Upload Class Material 
•	Update Notice Board
•	Upload Query 
•	Admission Control Panel
•	Assignment Section
•	Question creates
•	Grade report generate


Impact of this Project:

The impact of this project is increasingly dominating the current educational system as the impact of technology continuously dominates our everyday activities worldwide. It is to increase accessibility of education and reducing time as well as improving student’s academic performance. Students can view their lecture notes anytime by this, they don’t have to go outside from for this.

