<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
</head>
<body>
    <fieldset style="width: 98%;">
        <?php include('../View/header.php'); ?>
        <div style="float: right;">
            <a href="/Project/View/settings.php">🛠 Settings</a> | <a href="/Project/View/Logout.php">Logout</a>
        </div>
        <br>
        <div style="float: right;">
            <b>Teacher Panel</b>
        </div>
    </fieldset>
</body>
</html>
