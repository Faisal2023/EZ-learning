<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
	<a href="/ProjectEZ/Home.php"><img src="/ProjectEZ/View/img/EZlogo.png" alt="EZ learning logo" height="100em" width="100em"></a>
</body>
</html>

