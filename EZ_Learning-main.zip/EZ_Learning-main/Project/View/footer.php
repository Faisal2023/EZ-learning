<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
	<div style="width:100%; height:100px; border:1px solid #000;">

		<?php
			echo "<p> Copyright &copy; 2020-".date("Y")." Group_01</p>";
		?>

	</div>
</body>
</html>
