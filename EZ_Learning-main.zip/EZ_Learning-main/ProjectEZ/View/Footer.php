<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Footer</title>
    </head>
    <body>
        <div style="text-align: center;">   
            <li><a href="/ProjectEZ/View/TnC.php"><b> Terms and Condition</b></a><br><br></li>
            <footer><i>Copyright &copy;<?php echo date('Y'); ?> EZInstitute</i></footer>
        </div>
    </body>
</html>